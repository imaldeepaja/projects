﻿using Microsoft.AspNetCore.Mvc;

namespace SmartHomeEnergyManagement.Controllers
{
    public class RoomController : Controller
    {
        public IActionResult Kitchen()
        {
            ViewData["RoomName"] = "Kitchen";
            return View();
        }

        public IActionResult LivingRoom()
        {
            ViewData["RoomName"] = "Living Room";
            return View();
        }

        public IActionResult Bathroom()
        {
            ViewData["RoomName"] = "Bathroom";
            return View();
        }

        public IActionResult Bedroom01()
        {
            ViewData["RoomName"] = "Bedroom 01";
            return View();
        }

        public IActionResult Bedroom02()
        {
            ViewData["RoomName"] = "Bedroom 02";
            return View();
        }

        public IActionResult Veranda()
        {
            ViewData["RoomName"] = "Veranda";
            return View();
        }
    }
}
