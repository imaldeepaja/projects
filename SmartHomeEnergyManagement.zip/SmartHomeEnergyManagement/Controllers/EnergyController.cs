﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SmartHomeEnergyManagement.Models;

namespace SmartHomeEnergyManagement
{
    public class EnergyController : Controller
    {
        private static List<EnergyData> _data = new List<EnergyData>
        {
            new EnergyData { Id = 1, DeviceName = "Air Conditioner", EnergyConsumption = 1.5, Status = "On" },
            new EnergyData { Id = 2, DeviceName = "Refrigerator", EnergyConsumption = 0.8, Status = "On" },
            new EnergyData { Id = 3, DeviceName = "Washing Machine", EnergyConsumption = 2.0, Status = "Off" }
        };


        // GET: EnergyController
        public IActionResult Index()
        {
            return View(_data);
        }


        // GET: EnergyController/Details/5
        public IActionResult ToggleStatus(int id)
        {
            var device = _data.FirstOrDefault(d => d.Id == id);
            if (device != null)
            {
                device.Status = device.Status == "On" ? "Off" : "On";
            }
            return RedirectToAction("Index");
        }

              

        // GET: EnergyController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EnergyController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EnergyController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: EnergyController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EnergyController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: EnergyController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
