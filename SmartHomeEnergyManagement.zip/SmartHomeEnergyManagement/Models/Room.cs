﻿module Room

namespace SmartHomeEnergyManagement.Models
{
    public class Room
    {
        public string Name { get; set; }
        public double CurrentTemperature { get; set; } // in °C
        public double DesiredTemperature { get; set; } // in °C

        // Method to control temperature
        public string AdjustTemperature()
        {
            if (CurrentTemperature > DesiredTemperature)
                return "Cooling down...";
            else if (CurrentTemperature < DesiredTemperature)
                return "Heating up...";
            else
                return "Temperature is optimal.";
        }
    }
}


