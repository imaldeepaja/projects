﻿module EnergyData
namespace SmartHomeEnergyManagement.Models
{
    public class EnergyData
    {
        public int Id { get; set; }
        public string DeviceName { get; set; }
        public double EnergyConsumption { get; set; } // in kWh
        public string Status { get; set; } // On/Off
    }
}


